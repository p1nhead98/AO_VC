-----------------------------------------

HYDORAH �2010
V1.1 Released 08/12/2012

A game by Locomalito
Music by Gryzor87
Cover Art by Marek Barej

-----------------------------------------

CONTROLS

Moving --------------- ARROWS or joystick
Button 1 ------------- Z or joy button 1
Button 2 ------------- X or joy button 2
Pause ---------------- ESC

change resolution ---- F4
toggle scanlines ----- F5
toggle vsync --------- F6
take screenshot ------ F9


You can make your own key and buttons
configuration in the main menu

-----------------------------------------

KNOWN ISSUES

- If you don't have music playing, try
  installing the "ffdshow" codec package
- Windowsblinds can cause a startup crush
- Plugging a gamepad on the fly can
  cause lag for a few seconds.

-----------------------------------------

HYDORAH IS A FREEWARE GAME

You don't have to pay for playing,
but if you feel it worth it, you can 
support my games making a donation,
writing about the game, spreading the 
file or making your own freeware games.

www.locomalito.com

-----------------------------------------

Thanks to Andrewmc for creating SAUDIO
the .dll wich supports ingame music

-----------------------------------------

Have fun :-)

-----------------------------------------