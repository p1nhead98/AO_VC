-----------------------------------------

DARKULA

A game by Locomalito
Music by Gryzor87

-----------------------------------------

DEFAULKT KEYS

Arrows ---- Move around and use stairs
Space ----- Start & Jump
Esc ------- Exit game

XInput controllers are supported.
Keyboard input will be overridden if a
controller is detected.

-----------------------------------------

Configuration and hiscore files are
stored in your local App data folder,
not in the same folder of the program.

-----------------------------------------

THIS IS A FREEWARE/DONATIONWARE GAME

You can support my project with a
a donation or writing about this or
my other games. 

For more info visit www.locomalito.com

-----------------------------------------

Have fun :-)

-----------------------------------------